//import java.sql.Connection;
//import java.sql.DriverManager;
//
//public class Test {
//	public static void main(String[] args) throws Exception {
//        Class.forName("oracle.jdbc.OracleDriver");
//        Connection con = DriverManager.getConnection(
//            "jdbc:oracle:thin:@//localhost:1521/FREEPDB1", "SYSTEM", "Kashish123");
//        System.out.println("Connected to Oracle DB!");
////		System.out.println("Fetched Bugs: " + bugs);
//        con.close();
//    }
//}

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Test {
    public static void main(String[] args) throws Exception {
        Class.forName("oracle.jdbc.OracleDriver");
        Connection con = DriverManager.getConnection(
        	    "jdbc:oracle:thin:@//localhost:1521/FREEPDB1", "SYSTEM", "Kashish123");

        System.out.println("Connected to Oracle DB!");

        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM BUGTRACKER");
        System.out.println("Query executed");
        int count=0;
        while (rs.next()) {
        	count++;
        	System.out.println("Connected to Oracle DB!");
            int bugId = rs.getInt("BUGID");
            String title = rs.getString("TITLE");
            String empName = rs.getString("EMPNAME");
            java.sql.Date issueDate = rs.getDate("ISSUEDATE");
            String assigneeName = rs.getString("ASSIGNEENAME");
            String role = rs.getString("ROLE");
            String vacancyStatus = rs.getString("VACANCYSTATUS");
            String priority = rs.getString("PRIORITY");
            String bugStatus = rs.getString("BUGSTATUS");
            java.sql.Date resolvedDate = rs.getDate("RESOLVEDDATE");

            System.out.println("BugID: " + bugId + ", Title: " + title + ", EmpName: " + empName +
                    ", IssueDate: " + issueDate + ", AssigneeName: " + assigneeName +
                    ", Role: " + role + ", VacancyStatus: " + vacancyStatus +
                    ", Priority: " + priority + ", BugStatus: " + bugStatus +
                    ", ResolvedDate: " + resolvedDate);
            
            System.out.println(count);
        }
        System.out.println("Query count:" +count);

        rs.close();
        stmt.close();
        con.close();
    }
}

