package com.pgs.demo.bugSpringboot.BugTrackingSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BugTrackingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(BugTrackingSystemApplication.class, args);
	}

}
