package com.pgs.demo.bugSpringboot.BugTrackingSystem.controller;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Bug;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.service.BugService;
 
@CrossOrigin(origins="*") 
@RestController
@RequestMapping("/api")
public class BugController 
{
	@Autowired
	private BugService bugService;
	
	@GetMapping("/bugs")
	public List<Bug> getBugs()
	{
		List<Bug> bugs = bugService.getBugs();
		System.out.println("Fetched Bugs: " + bugs);
		return  bugs;
	}
	
	@GetMapping("/bugs/{bugId}")
	public Bug  getBug(@PathVariable int bugId)
	{
		Bug bug = bugService.getBug(bugId);
		if(bug==null) {
			throw new BugNotFoundException("BugId Not Found, Please enter another Id") ;
		}
		return bug;
	}
	
	@PostMapping("/bugs")
	public Bug addBug(@RequestBody Bug theBug)
	{
		Bug bug = bugService.save1(theBug);
		return bug;
	}
	
	@PutMapping("/bugs")
	public Bug updateBug(@RequestBody Bug theBug)
	{
		Bug bug = bugService.save1(theBug);
		return bug;
	}
	
	@DeleteMapping("/bugs/{bugId}")
	public void deleteBug(@PathVariable int bugId)
	{
		bugService.deleteBug(bugId);
	}
	
	
//	to assign the developer
	@PostMapping("/bugs/{bugId}/assign")
	public ResponseEntity<String> assignDeveloper(@PathVariable int bugId){
		try {
			bugService.assignedDeveloperToBug(bugId);
			return ResponseEntity.ok("Developer assigned successfully");
		}
		catch(RuntimeException e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}
	
//	to update the status of bug as open or closed
	@PutMapping("/updatestatus/{bugId}/{bugStatus}")
	public ResponseEntity<String> updateBugStatus(@PathVariable int bugId, @PathVariable String bugStatus){
		bugService.updateBugStatus(bugId, bugStatus);
		
		return ResponseEntity.ok("Bug Status Updated Successfully");
	}

}