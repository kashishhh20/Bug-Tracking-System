package com.pgs.demo.bugSpringboot.BugTrackingSystem.controller;

public class BugNotFoundException extends RuntimeException {
	
	public BugNotFoundException()
	{
		
	}
	
	public BugNotFoundException(String message)
	{
		super(message);
	}
}
