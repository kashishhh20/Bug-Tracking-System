package com.pgs.demo.bugSpringboot.BugTrackingSystem.controller;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class BugRestExceptionHandler {

		@ExceptionHandler
		public ResponseEntity <BugErrorResponse> handleException(BugNotFoundException bnfe)
		{
			BugErrorResponse err = new BugErrorResponse(
											HttpStatus.NOT_FOUND.value(),
											bnfe.getMessage(),
											System.currentTimeMillis());
			return new ResponseEntity(err,HttpStatus.NOT_FOUND);
					
		}
		
		@ExceptionHandler
		public ResponseEntity <BugErrorResponse> handleException( Exception e)
		{
			BugErrorResponse err = new BugErrorResponse(
											HttpStatus.BAD_REQUEST.value(),
											e.getMessage(),
											System.currentTimeMillis());
			return new ResponseEntity(err,HttpStatus.BAD_REQUEST);
					
		}
}

