package com.pgs.demo.bugSpringboot.BugTrackingSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.OpenBugs;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.service.OpenBugsService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class OpenBugsController {
	@Autowired
	private OpenBugsService openBugsService;
	
	@GetMapping("/openbugs")
	public List<OpenBugs> getOpenBugs()
	{
		List<OpenBugs> openbugs = openBugsService.getOpenBugs();
		return  openbugs;
	}
	
	@GetMapping("/openbugs/{bugId}")
	public OpenBugs  getOpenBug(@PathVariable int bugId)
	{
		OpenBugs openBug = openBugsService.getOpenBug(bugId);
		if(openBug==null) {
			throw new BugNotFoundException("BugId Not Found, Please enter another Id") ;
		}
		return openBug;
	}
}
