package com.pgs.demo.bugSpringboot.BugTrackingSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.dto.LoginRequest;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Register;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.service.RegisterService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class RegisterController {
	
	@Autowired
	private RegisterService registerService;
	
	@PostMapping("/register")
	public String registerUser(@RequestBody Register register) {
		return registerService.registerUser(register);
	}
	
	@GetMapping("/all")
	public List<Register> getAllUsers(){
		return registerService.getAllUsers();
	}
	
	@PostMapping("/login")
	public String login(@RequestBody LoginRequest loginRequest) {
		return registerService.login(loginRequest.getUsername(), loginRequest.getPassword(),loginRequest.getRole());
	}
}
