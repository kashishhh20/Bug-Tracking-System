package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.AssignedUser;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Bug;

@Repository
public interface AssignedUserDAO {
	Optional<AssignedUser>findFirstByRoleAndVacancyStatus(String role, String vacancyStatus);

	void update(AssignedUser user);

	List<AssignedUser> getUsers();

	AssignedUser getUser(int id);

	AssignedUser save(AssignedUser user);

	void deleteUser(int id);

	void updateVacancyStatus(String assigneeName, String role, String string);
}

