package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.AssignedUser;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Bug;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository
public class AssignedUserDAOImpl implements AssignedUserDAO {
	
	@PersistenceContext
	@Autowired
	private EntityManager entityManager;
	
	@Override
	public Optional<AssignedUser>findFirstByRoleAndVacancyStatus(String role, String vacancyStatus){
	    try {
	        return entityManager.createQuery(
	                "SELECT u FROM AssignedUser u WHERE u.role = :role AND u.vacancyStatus = :vacancyStatus", 
	                AssignedUser.class)
	                .setParameter("role", role)
	                .setParameter("vacancyStatus", vacancyStatus)
	                .setMaxResults(1)
	                .getResultStream()
	                .findFirst();
	    } catch (Exception e) {
	        e.printStackTrace();
	        return Optional.empty();
	    }
	}

	
	@Override
	@Transactional
	public List<AssignedUser> getUsers() {
		
		Session currentSession = entityManager.unwrap(Session.class);
		Query theQuery = currentSession.createQuery("from AssignedUser",AssignedUser.class);
		
		return theQuery.getResultList();
	}
	
	@Override
	@Transactional
	public AssignedUser getUser(int userId) {
		Session cursess = entityManager.unwrap(Session.class);
		AssignedUser user = cursess.get(AssignedUser.class, userId);
		return user;
		
	}
	
	@Override
	@Transactional
	// for add operation
	public AssignedUser save(AssignedUser user) {
		Session cursess = entityManager.unwrap(Session.class);
		cursess.saveOrUpdate(user);
		return user;
	}
	
	@Override
	@Transactional
	public void deleteUser(int userId)
	{
			Session currentSession = entityManager.unwrap(Session.class);
			AssignedUser user = currentSession.get(AssignedUser.class, userId);
			currentSession.remove(user);
		
	}
	
	@Override
	@Transactional
	public void update(AssignedUser user) {
		// TODO Auto-generated method stub
		entityManager.merge(user);
	}


	@Override
	@Transactional
	public void updateVacancyStatus(String assigneeName, String role, String status) {
		// TODO Auto-generated method stub
		String sql = "UPDATE assigneduser a SET a.vacancystatus=:status WHERE a.assigneename=:assigneeName AND a.role=:role";
		entityManager.createNativeQuery(sql).setParameter("status", status).setParameter("assigneeName", assigneeName).setParameter("role", role).executeUpdate();
	}
	
	
}

