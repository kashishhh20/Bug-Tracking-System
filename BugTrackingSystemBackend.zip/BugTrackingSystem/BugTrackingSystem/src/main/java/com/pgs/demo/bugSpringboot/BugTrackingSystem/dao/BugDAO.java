package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.AssignedUser;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Bug;

@Repository
public interface BugDAO {

	List<Bug> getBugs();

	Bug getBug(int bugId);

	void deleteBug(int bugId);

	Bug save1(Bug theBug);

	Bug save2(Bug theBug);

	Optional<Bug> FindById(int bugId);

	void update(Bug thebug);
	
	void deleteById(int bugId);
}
