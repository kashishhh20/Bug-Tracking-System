package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Bug;

import jakarta.persistence.EntityManager;
 
@Repository
public class BugDAOImpl implements BugDAO {
	
	@Autowired
	private EntityManager entityManager;

 
	@Override
	public List<Bug> getBugs() {
		
		Session currentSession = entityManager.unwrap(Session.class);
		Query theQuery = currentSession.createQuery("from Bug",Bug.class);
		
		return theQuery.getResultList();
	}
	
	@Override
	@Transactional
	public Bug getBug(int bugId) {
		Session cursess = entityManager.unwrap(Session.class);
		Bug bug = cursess.get(Bug.class, bugId);
		return bug;
	}
	
	/*@Override
	@Transactional
	public Bug save(Bug theBug) {
		Session cursess = entityManager.unwrap(Session.class);
		cursess.saveOrUpdate(theBug);
		return theBug;
	} */
	
	
	@Override
	@Transactional
	// for add operation
	public Bug save1(Bug theBug) {
		Session cursess = entityManager.unwrap(Session.class);
		cursess.saveOrUpdate(theBug);
		return theBug;
	}
	
	
	@Override
	@Transactional
	// for update operation
	public Bug save2(Bug theBug) {
		Session cursess = entityManager.unwrap(Session.class);
		cursess.saveOrUpdate(theBug);
		return theBug;
	}
	
	@Override
	@Transactional
	public void deleteBug(int bugId)
	{
			Session currentSession = entityManager.unwrap(Session.class);
			Bug theBug = currentSession.get(Bug.class, bugId);
			currentSession.remove(theBug);
		
	}
	
	@Override
	@Transactional
	public Optional<Bug>FindById(int bugId){
		
		return Optional.ofNullable(entityManager.find(Bug.class, bugId));
	}
	
	@Override
	@Transactional
	public void update(Bug thebug) {
		entityManager.merge(thebug);
	}
	
	@Override
	@Transactional
	public void deleteById(int bugId) {
		Bug bug = entityManager.find(Bug.class, bugId);
		if(bug != null) {
			entityManager.remove(bug);
		}
	}
 
}

