package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.OpenBugs;

public interface OpenBugDAO {

	void insert(OpenBugs openBugs);
	
	void deleteById(int bugId);
}
