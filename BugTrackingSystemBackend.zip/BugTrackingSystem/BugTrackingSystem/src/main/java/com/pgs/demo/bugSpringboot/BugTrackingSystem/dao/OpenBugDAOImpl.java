package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.OpenBugs;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Repository
public class OpenBugDAOImpl implements OpenBugDAO{
	
	@Autowired
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public void insert(OpenBugs openBugs) {
		entityManager.persist(openBugs);
	}

	@Override
	@Transactional
	public void deleteById(int bugId) {
		OpenBugs openBug =entityManager.find(OpenBugs.class, bugId);
		if(openBug != null ) {
			entityManager.remove(openBug);
		}
	}
	
}

