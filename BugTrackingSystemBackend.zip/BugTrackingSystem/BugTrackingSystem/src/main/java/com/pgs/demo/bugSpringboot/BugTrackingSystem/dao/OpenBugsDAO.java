package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.OpenBugs;

@Repository
public interface OpenBugsDAO {

	List<OpenBugs> getOpenBugs();

	OpenBugs getOpenBug(int bugId);

}

