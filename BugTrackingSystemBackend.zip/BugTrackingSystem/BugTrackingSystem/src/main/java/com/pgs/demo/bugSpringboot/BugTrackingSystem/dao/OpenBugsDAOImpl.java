package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Bug;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.OpenBugs;

import jakarta.persistence.EntityManager;

@Repository
public class OpenBugsDAOImpl implements OpenBugsDAO{

	@Autowired
	private EntityManager entityManager;
	
	@Override
	public List<OpenBugs> getOpenBugs() {
		Session currentSession = entityManager.unwrap(Session.class);
		Query theQuery = currentSession.createQuery("from OpenBugs",OpenBugs.class);
		
		return theQuery.getResultList();
	}

	@Override
	public OpenBugs getOpenBug(int bugId) {
		Session cursess = entityManager.unwrap(Session.class);
		OpenBugs openBugs = cursess.get(OpenBugs.class, bugId);
		return openBugs;
	}

}
