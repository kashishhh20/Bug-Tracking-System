package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Register;

@Repository
public interface RegisterDAO {
	
	void save(Register register);
	
	boolean existsByUsername (String username);
	
	List <Register> findAll();
	
//	for login matching 
	
	Register findByUsernameAndPassword(String username, String password, String role);
	
}
