package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import java.util.List;
import java.util.Optional;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Bug;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Register;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Repository
public class RegisterDAOImpl implements RegisterDAO{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void save(Register register) {
		entityManager.persist(register);	
	}

	@Override
	public boolean existsByUsername(String username) {
		String jpql = "SELECT COUNT(u) FROM Register u WHERE u.username =: username";
		Long count = entityManager.createQuery(jpql,Long.class).setParameter("username", username).getSingleResult();
		return count>0;
	}

	@Override
	public List<Register> findAll() {
		
		Session currentSession = entityManager.unwrap(Session.class);
		Query theQuery = currentSession.createQuery("from Register",Register.class);
		
		return theQuery.getResultList();
	}

	@Override
	public Register findByUsernameAndPassword(String username, String password, String role) {
		
		String jpql = "SELECT u FROM Register u WHERE u.username=:username AND u.password=:password AND u.role=:role";
		List<Register> result = entityManager.createQuery(jpql,Register.class).setParameter("username", username).setParameter("password", password).setParameter("role", role).getResultList();
		
		return result.isEmpty()?null:result.get(0);
	}
}
