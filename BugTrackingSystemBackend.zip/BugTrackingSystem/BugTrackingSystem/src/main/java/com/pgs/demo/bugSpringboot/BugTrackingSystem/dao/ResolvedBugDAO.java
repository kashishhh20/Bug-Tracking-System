package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import java.util.List;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.ResolvedBugs;

public interface ResolvedBugDAO {
	
	void insert(ResolvedBugs resolvedBug);

	ResolvedBugs getResolvedBug(int bugId);

	List<ResolvedBugs> getResolvedBugs();
}
