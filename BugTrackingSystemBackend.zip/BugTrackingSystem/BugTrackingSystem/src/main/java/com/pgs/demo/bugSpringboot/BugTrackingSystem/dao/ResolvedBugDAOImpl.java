package com.pgs.demo.bugSpringboot.BugTrackingSystem.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.OpenBugs;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.ResolvedBugs;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Repository
public class ResolvedBugDAOImpl implements ResolvedBugDAO {

	@Autowired
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public void insert(ResolvedBugs resolvedBugs) {
		entityManager.persist(resolvedBugs);
	}


	@Override
	public List<ResolvedBugs> getResolvedBugs() {
		Session currentSession = entityManager.unwrap(Session.class);
		Query theQuery = currentSession.createQuery("from ResolvedBugs",ResolvedBugs.class);
		
		return theQuery.getResultList();
	}
	
	@Override
	public ResolvedBugs getResolvedBug(int bugId) {
		Session cursess = entityManager.unwrap(Session.class);
		ResolvedBugs resolvedBug = cursess.get(ResolvedBugs.class, bugId);
		return resolvedBug;
	}

}

