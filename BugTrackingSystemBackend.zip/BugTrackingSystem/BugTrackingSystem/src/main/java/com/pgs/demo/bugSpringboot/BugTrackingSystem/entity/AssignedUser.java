package com.pgs.demo.bugSpringboot.BugTrackingSystem.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name="ASSIGNEDUSER")
@SequenceGenerator(name ="myAssigneeSequence", sequenceName="ASSIGNEESEQUENCE", initialValue = 1, allocationSize=1)
public class AssignedUser {
	
	@Id
	@Column(name="ASSIGNEEID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "myAssigneeSequence")
	private int assigneeId;
	
	@Column(name="ASSIGNEENAME")
	private String assigneeName;
	
	@Column(name="ROLE")
	private String role;
	
	@Column(name="VACANCYSTATUS")
	
	private String vacancyStatus;
	public int getAssigneeId() {
		return assigneeId;
	}
	public void setAssigneeId(int assigneeId) {
		this.assigneeId = assigneeId;
	}
	public String getAssigneeName() {
		return assigneeName;
	}
	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getVacancyStatus() {
		return vacancyStatus;
	}
	public void setVacancyStatus(String vacancyStatus) {
		this.vacancyStatus = vacancyStatus;
	}
	@Override
	public String toString() {
		return "AssignedUser [assigneeId=" + assigneeId + ", assigneeName=" + assigneeName + ", role=" + role
				+ ", vacancyStatus=" + vacancyStatus + "]";
	}
	public AssignedUser(int assigneeId, String assigneeName, String role, String vacancyStatus) {
		super();
		this.assigneeId = assigneeId;
		this.assigneeName = assigneeName;
		this.role = role;
		this.vacancyStatus = vacancyStatus;
	}
	public AssignedUser() {
		super();
	}	
}
