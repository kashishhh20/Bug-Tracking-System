package com.pgs.demo.bugSpringboot.BugTrackingSystem.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name ="BUGTRACKER")
@SequenceGenerator(name ="mySequence", sequenceName="BUGSEQUENCE", initialValue = 1, allocationSize=1)
public class Bug {
	@Id
	@Column(name="BUGID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "mySequence")
	private int bugId;
	
	@Column(name="TITLE")
	private String title;
	
	@Column(name="EMPNAME")
	private String empName;
	
	@Column(name="ISSUEDATE")
	private Date issueDate;
	
	@Column(name="ASSIGNEENAME")
	private String assigneeName;
	
	@Column(name="ROLE")
	private String role;
	
	@Column(name="VACANCYSTATUS")
	private String vacancyStatus;
	
	@Column(name="PRIORITY")
	private String priority;
	
	@Column(name="BUGSTATUS")
	private String bugStatus;
	
	@Column(name="RESOLVEDDATE")
	private Date resolvedDate;

	public int getBugId() {
		return bugId;
	}

	public void setBugId(int bugId) {
		this.bugId = bugId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public String getAssigneeName() {
		return assigneeName;
	}

	public void setAssigneeName(String assigneeName) {
		this.assigneeName = assigneeName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getVacancyStatus() {
		return vacancyStatus;
	}

	public void setVacancyStatus(String vacancyStatus) {
		this.vacancyStatus = vacancyStatus;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getBugStatus() {
		return bugStatus;
	}

	public void setBugStatus(String bugStatus) {
		this.bugStatus = bugStatus;
	}

	public Date getResolvedDate() {
		return resolvedDate;
	}

	public void setResolvedDate(Date resolvedDate) {
		this.resolvedDate = resolvedDate;
	}

	public Bug() {
		super();
	}

	public Bug(int bugId, String title, int empId, String empName, Date issueDate, int assigneeId, String assigneeName,
			String role, String vacancyStatus, String priority, String bugStatus, Date resolvedDate) {
		super();
		this.bugId = bugId;
		this.title = title;
		this.empName = empName;
		this.issueDate = issueDate;
		this.assigneeName = assigneeName;
		this.role = role;
		this.vacancyStatus = vacancyStatus;
		this.priority = priority;
		this.bugStatus = bugStatus;
		this.resolvedDate = resolvedDate;
	}

	@Override
	public String toString() {
		return "Bug [bugId=" + bugId + ", title=" + title  + ", empName=" + empName + ", issueDate="
				+ issueDate + ", assigneeName=" + assigneeName + ", role=" + role
				+ ", vacancyStatus=" + vacancyStatus + ", priority=" + priority + ", bugStatus=" + bugStatus
				+ ", resolvedDate=" + resolvedDate + "]";
	}

}