package com.pgs.demo.bugSpringboot.BugTrackingSystem.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="OPENBUGS")

public class OpenBugs {
	
	@Id
	@Column(name="BUGID")
	private int bugId;
	
	@Column(name="TITLE")
	private String title;
	
	@Column(name="ISSUEDATE")
	private Date issueDate;

	public int getBugId() {
		return bugId;
	}

	public void setBugId(int bugId) {
		this.bugId = bugId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public OpenBugs(int bugId, String title, Date issueDate) {
		super();
		this.bugId = bugId;
		this.title = title;
		this.issueDate = issueDate;
	}

	public OpenBugs() {
		super();
	}

	@Override
	public String toString() {
		return "OpenBugs [bugId=" + bugId + ", title=" + title + ", issueDate=" + issueDate + "]";
	}
}
