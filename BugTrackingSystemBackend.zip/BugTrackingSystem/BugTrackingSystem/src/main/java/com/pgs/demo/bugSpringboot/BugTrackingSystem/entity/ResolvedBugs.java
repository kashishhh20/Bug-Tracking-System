package com.pgs.demo.bugSpringboot.BugTrackingSystem.entity;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="RESOLVEDBUGS")
public class ResolvedBugs {
	
	@Id
	@Column(name="BUGID")
	private int bugId;
	
	@Column(name="TITLE")
	private String title;
	
	@Column(name="ISSUEDATE")
	private Date issueDate;
	
	@Column(name="RESOLVEDDATE")
	private Date resolvedDate;

	public int getBugId() {
		return bugId;
	}

	public void setBugId(int bugId) {
		this.bugId = bugId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public Date getResolvedDate() {
		return resolvedDate;
	}

	public void setResolvedDate(Date resolvedDate) {
		this.resolvedDate = resolvedDate;
	}

	public ResolvedBugs() {
		super();
	}

	public ResolvedBugs(int bugId, String title, Date issueDate, Date resolvedDate) {
		super();
		this.bugId = bugId;
		this.title = title;
		this.issueDate = issueDate;
		this.resolvedDate = resolvedDate;
	}

	@Override
	public String toString() {
		return "ResolvedBugs [bugId=" + bugId + ", title=" + title + "]";
	}
	
	
}
