package com.pgs.demo.bugSpringboot.BugTrackingSystem.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.AssignedUser;

public interface AssignedUserService {
	
	List<AssignedUser> getUsers();

	AssignedUser getUser(int id);
	
	AssignedUser save(AssignedUser user);
	
	void deleteUser(int id);
	
	void update(AssignedUser user);
}

