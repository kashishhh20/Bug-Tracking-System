package com.pgs.demo.bugSpringboot.BugTrackingSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.dao.AssignedUserDAO;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.AssignedUser;

@Service 
public class AssignedUserServiceImpl implements AssignedUserService {

	@Autowired 
	private AssignedUserDAO assignedUserDAO;
	
	@Transactional
	@Override
	public List<AssignedUser> getUsers() {
		return assignedUserDAO.getUsers();
	}

	@Transactional
	@Override
	public AssignedUser getUser(int id) {
		return assignedUserDAO.getUser(id);
	}

	@Transactional
	@Override
	public AssignedUser save(AssignedUser user) {
		return assignedUserDAO.save(user);
	}

	@Transactional
	@Override
	public void deleteUser(int id) {
		assignedUserDAO.deleteUser(id);
	}
	
	@Transactional
	@Override
	public void update(AssignedUser user) {
		assignedUserDAO.update(user);
	}

}
