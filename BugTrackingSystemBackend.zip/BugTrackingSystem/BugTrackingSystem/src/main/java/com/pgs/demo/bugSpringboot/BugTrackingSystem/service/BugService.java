package com.pgs.demo.bugSpringboot.BugTrackingSystem.service;

import java.util.List;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Bug;

public interface BugService {
	List<Bug> getBugs();

	Bug getBug(int bugId);


	void deleteBug(int bugId);

	Bug save1(Bug theBug);

	Bug save2(Bug theBug);
	
	void assignedDeveloperToBug(int bugId);

	void updateBugStatus(int bugId, String status);

}
