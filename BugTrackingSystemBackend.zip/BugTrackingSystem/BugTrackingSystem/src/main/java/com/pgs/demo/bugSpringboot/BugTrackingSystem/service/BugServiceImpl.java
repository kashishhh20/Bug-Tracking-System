package com.pgs.demo.bugSpringboot.BugTrackingSystem.service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.dao.AssignedUserDAO;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.dao.BugDAO;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.dao.OpenBugDAO;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.dao.ResolvedBugDAO;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.AssignedUser;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Bug;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.OpenBugs;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.ResolvedBugs;

@Service 
public class BugServiceImpl implements BugService{
	@Autowired
	private BugDAO bugDAO;
	
	@Autowired 
	private AssignedUserDAO assignedUserDAO;
	
	@Autowired
	private ResolvedBugDAO resolvedBugDAO;
	
	@Autowired
	private OpenBugDAO openBugDAO;
	
	@Transactional
	@Override
	public List<Bug> getBugs() {
		
		return bugDAO.getBugs();
	}
	
	@Override
	@Transactional
	public Bug getBug(int bugId) {
		return bugDAO.getBug(bugId);
		
	}
	

	@Override
	@Transactional
	public Bug save1(Bug theBug) {
		Bug savedBug = bugDAO.save1(theBug);
		if("Open".equalsIgnoreCase(theBug.getBugStatus())) {
			OpenBugs openBugs = new OpenBugs();
			openBugs.setBugId(savedBug.getBugId());
			openBugs.setTitle(savedBug.getTitle());
			openBugs.setIssueDate(savedBug.getIssueDate());
			
			openBugDAO.insert(openBugs);
		}
		return savedBug;
	}
	@Override
	@Transactional
	public Bug save2(Bug theBug) {
		return bugDAO.save2(theBug);
	}
	
	
//	@Override
//	@Transactional
//	public void deleteBug(int bugId)
//	{
//		bugDAO.deleteBug(bugId);
//		
//	}
	

	@Override
	@Transactional
	
	public void deleteBug(int bugId) {
		Bug bugg = bugDAO.getBug(bugId);
		
		if("closed".equalsIgnoreCase(bugg.getBugStatus())) {
			bugDAO.deleteBug(bugId);
		}
		else {
			System.out.println("Bug cannot be deleted as it is not closed.");
		}
	}

	
	@Override
	@Transactional
	public void assignedDeveloperToBug(int bugId) {
			Optional<Bug> bugOptional = bugDAO.FindById(bugId);
			if(bugOptional.isPresent()) {
				Bug bug = bugOptional.get();
				
				String title = bug.getTitle().toLowerCase();
				String assignedRole = determineRoleBasedOnTitle(title);
				Optional<AssignedUser>availableDev=assignedUserDAO.findFirstByRoleAndVacancyStatus(assignedRole, "Y");
				if(availableDev.isPresent()) {
					
					AssignedUser dev = availableDev.get();
					dev.setVacancyStatus("N");
					assignedUserDAO.update(dev);
					bug.setAssigneeName(dev.getAssigneeName());
					bug.setRole(assignedRole);
					bug.setVacancyStatus("N");
					bugDAO.update(bug);
				}
		
			else {
				throw new RuntimeException("bugNotFound with Id " + bugId);
			}	
		}
		else {
			
			throw new RuntimeException("Person Not Found");
		}
	}
	
	private String determineRoleBasedOnTitle(String title) {
		if(title.contains("ui/ux") || title.contains("compatibility")) {
			return "Tester";
		}
		else if(title.contains("logical") || title.contains("database")) {
			return "Developer";
		}
		else if(title.contains("security") || title.contains("performance")) {
			return "Admin";
		}
		
		return "Unassigned";
	}
	
	@Override
	@Transactional
	public void updateBugStatus(int bugId, String bugStatus) {
		Optional<Bug> bugOptional = bugDAO.FindById(bugId);
		if(bugOptional.isPresent()) {
			Bug  bug = bugOptional.get();
			bug.setBugStatus(bugStatus);
			
			if("Closed".equalsIgnoreCase(bugStatus)) {
				ResolvedBugs resolvedBugs = new ResolvedBugs();
				resolvedBugs.setBugId(bug.getBugId());
				resolvedBugs.setTitle(bug.getTitle());
				resolvedBugs.setIssueDate(bug.getIssueDate());
				resolvedBugs.setResolvedDate(new Date(System.currentTimeMillis()));
				resolvedBugDAO.insert(resolvedBugs);
				
				String assigneeName = bug.getAssigneeName();
				String role = bug.getRole();
				if(assigneeName != null && !assigneeName.isEmpty()) {
					assignedUserDAO.updateVacancyStatus(assigneeName,role,"Y");
				}
				bugDAO.deleteById(bugId);
				openBugDAO.deleteById(bugId);
				System.out.println("Bug Removed");
			}
			else if("Open".equalsIgnoreCase(bugStatus)){
				OpenBugs openBugs = new OpenBugs();
				openBugs.setBugId(bugId);
				openBugs.setTitle(bug.getTitle());
				openBugs.setIssueDate(bug.getIssueDate());
				openBugDAO.insert(openBugs);
				System.out.println("Bug Added");
				bugDAO.update(bug);
			}
			else {
				throw new RuntimeException("Bug not found with Id " + bugId);
			}
		}
	}
}
