package com.pgs.demo.bugSpringboot.BugTrackingSystem.service;

import java.util.List;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.OpenBugs;

public interface OpenBugsService {

	List<OpenBugs> getOpenBugs();

	OpenBugs getOpenBug(int bugId);

}

