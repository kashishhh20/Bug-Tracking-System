package com.pgs.demo.bugSpringboot.BugTrackingSystem.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.dao.OpenBugsDAO;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.OpenBugs;

@Service 
public class OpenBugsServiceImpl implements OpenBugsService {

	@Autowired 
	private OpenBugsDAO openBugsDAO;
	@Override
	public List<OpenBugs> getOpenBugs() {
		return openBugsDAO.getOpenBugs();
	}

	@Override
	public OpenBugs getOpenBug(int bugId) {
		return openBugsDAO.getOpenBug(bugId);
	}

}

