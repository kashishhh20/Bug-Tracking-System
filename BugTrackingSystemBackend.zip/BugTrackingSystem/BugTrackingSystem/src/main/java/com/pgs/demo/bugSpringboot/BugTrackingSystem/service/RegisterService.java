package com.pgs.demo.bugSpringboot.BugTrackingSystem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Register;

@Service
public interface RegisterService {
	String registerUser(Register register);
	
	List<Register> getAllUsers();
	
	String login(String username, String password, String role);
}
