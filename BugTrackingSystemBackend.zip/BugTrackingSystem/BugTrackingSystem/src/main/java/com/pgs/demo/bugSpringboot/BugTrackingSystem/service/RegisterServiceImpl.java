package com.pgs.demo.bugSpringboot.BugTrackingSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.dao.RegisterDAO;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.Register;

@Service
public class RegisterServiceImpl implements RegisterService{

	@Autowired
	private RegisterDAO registerDAO;
	
//	public RegisterServiceImpl(RegisterDAO registerDAO) {
//		this.registerDAO = registerDAO;
//	}
		
	@Override
	@Transactional
	public String registerUser(Register register) {
		if(registerDAO.existsByUsername(register.getUsername())){
			return "Userame Already Exists";
		}
		
		registerDAO.save(register);
		return "User Registered Successfully";
	}

	@Override
	@Transactional
	public List<Register> getAllUsers() {
		return registerDAO.findAll();
	}

	@Override
	@Transactional
	public String login(String username, String password,String role) {
		Register user = registerDAO.findByUsernameAndPassword(username, password,role);
		
		if(user != null) {
			return "Login Successfull, Welcome " + user.getName();
			}
		
		else {
			return "Invalid username/password";
		}
	}

}
