package com.pgs.demo.bugSpringboot.BugTrackingSystem.service;

import java.util.List;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.ResolvedBugs;

public interface ResolvedBugsService {
	List<ResolvedBugs> getResolvedBugs();

	ResolvedBugs getResolvedBug(int bugId);
}

