package com.pgs.demo.bugSpringboot.BugTrackingSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pgs.demo.bugSpringboot.BugTrackingSystem.dao.OpenBugsDAO;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.dao.ResolvedBugDAO;
import com.pgs.demo.bugSpringboot.BugTrackingSystem.entity.ResolvedBugs;

@Service
public class ResolvedBugsServiceImpl implements ResolvedBugsService{

	@Autowired 
	private ResolvedBugDAO resolvedBugDAO;
	
	@Override
	public List<ResolvedBugs> getResolvedBugs() {
		return resolvedBugDAO.getResolvedBugs();
	}

	@Override
	public ResolvedBugs getResolvedBug(int bugId) {
		return resolvedBugDAO.getResolvedBug(bugId);
	}

}


